/*
See the LICENSE.txt file for this sample’s licensing information.

Abstract:
The app.
*/

import SwiftUI

@main
struct EmojiRangersApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
